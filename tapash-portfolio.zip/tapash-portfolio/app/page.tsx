'use client'

import Nav from '@/components/Nav'
import Hero from '@/components/Hero'
import About from '@/components/About'
import Skills from '@/components/Skills'
import Projects from '@/components/Projects'
import BlogSection from '@/components/BlogSection'
import Certifications from '@/components/Certifications'
import Timeline from '@/components/Timeline'
import Contact from '@/components/Contact'
import Footer from '@/components/Footer'

export default function Home() {
  return (
    <main className="relative">
      <Nav />
      <Hero />
      <About />
      <Skills />
      <Projects />
      <BlogSection />
      <Certifications />
      <Timeline />
      <Contact />
      <Footer />
    </main>
  )
}

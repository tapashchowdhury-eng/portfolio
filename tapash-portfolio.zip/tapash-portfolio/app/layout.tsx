import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'Tapash Chowdhury | Cloud & Security Engineer',
  description: 'Cloud & Security Engineer specializing in Azure, Active Directory, Fortinet, and infrastructure automation. Building secure, resilient systems.',
  keywords: ['Cloud Engineer', 'Security Engineer', 'Azure', 'Active Directory', 'Fortinet', 'PowerShell', 'Infrastructure', 'Cybersecurity'],
  authors: [{ name: 'Tapash Chowdhury' }],
  openGraph: {
    title: 'Tapash Chowdhury | Cloud & Security Engineer',
    description: 'Designing secure cloud infrastructure, automation and resilient systems.',
    type: 'website',
    url: 'https://tapash.dev',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Tapash Chowdhury | Cloud & Security Engineer',
    description: 'Designing secure cloud infrastructure, automation and resilient systems.',
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" className="dark">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link rel="icon" href="data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22><text y=%22.9em%22 font-size=%2290%22>⚡</text></svg>" />
      </head>
      <body className="noise-overlay scanline">
        {children}
      </body>
    </html>
  )
}

import type { Metadata } from 'next'
import Link from 'next/link'

export const metadata: Metadata = {
  title: 'Blog | Tapash Chowdhury',
  description: 'Technical articles on cloud infrastructure, cybersecurity, and automation.',
}

const articles = [
  {
    slug: 'securing-active-directory',
    title: 'Securing Active Directory in Enterprise Environments',
    excerpt: 'A comprehensive guide to hardening Active Directory against modern attack vectors.',
    date: '2026-02-15',
    readTime: '12 min',
    tags: ['Active Directory', 'Security', 'Windows'],
  },
  {
    slug: 'powershell-automation',
    title: 'PowerShell Automation for Infrastructure Engineers',
    excerpt: 'Practical automation patterns for enterprise infrastructure management.',
    date: '2026-01-28',
    readTime: '8 min',
    tags: ['PowerShell', 'Automation', 'Infrastructure'],
  },
  {
    slug: 'enterprise-file-services',
    title: 'Best Practices for Enterprise File Services',
    excerpt: 'DFS namespace design, tiered storage strategies, and access-based enumeration.',
    date: '2026-01-10',
    readTime: '10 min',
    tags: ['DFS', 'NAS', 'Infrastructure'],
  },
]

export default function BlogPage() {
  return (
    <main className="min-h-screen bg-[#050810] px-6 py-24">
      <div className="max-w-4xl mx-auto">
        <div className="mb-16">
          <Link href="/" className="font-mono text-xs text-[#475569] hover:text-[#00a8ff] transition-colors mb-8 inline-flex items-center gap-2">
            ← Back to Portfolio
          </Link>
          <h1 className="text-5xl font-black mt-6 mb-4">
            <span className="text-[#e2e8f0]">Technical </span>
            <span className="gradient-text-blue">Blog</span>
          </h1>
          <p className="text-[#64748b]">
            Insights on cloud infrastructure, cybersecurity, and automation.
          </p>
        </div>

        <div className="space-y-6">
          {articles.map((article) => (
            <Link
              key={article.slug}
              href={`/blog/${article.slug}`}
              className="block cyber-border p-8 bg-[rgba(10,15,30,0.6)] card-hover group"
            >
              <div className="flex flex-wrap gap-2 mb-3">
                {article.tags.map((tag) => (
                  <span key={tag} className="tech-tag">{tag}</span>
                ))}
              </div>
              <h2 className="text-xl font-bold text-[#e2e8f0] group-hover:text-[#00a8ff] transition-colors mb-2">
                {article.title}
              </h2>
              <p className="text-[#64748b] text-sm mb-4">{article.excerpt}</p>
              <div className="flex gap-4">
                <span className="font-mono text-xs text-[#334155]">{article.date}</span>
                <span className="font-mono text-xs text-[#334155]">// {article.readTime} read</span>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </main>
  )
}

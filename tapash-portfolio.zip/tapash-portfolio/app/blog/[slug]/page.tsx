import type { Metadata } from 'next'
import Link from 'next/link'
import { notFound } from 'next/navigation'

const articles: Record<string, {
  title: string
  date: string
  readTime: string
  tags: string[]
  content: string
}> = {
  'securing-active-directory': {
    title: 'Securing Active Directory in Enterprise Environments',
    date: '2026-02-15',
    readTime: '12 min',
    tags: ['Active Directory', 'Security', 'Windows'],
    content: `
## Introduction

Active Directory (AD) is the backbone of enterprise identity management—and the number one target for attackers in Windows environments. In this article, I'll cover the key hardening steps I've implemented across enterprise production environments.

## The Tiered Administration Model

The most impactful change you can make is implementing a **three-tier administrative model**:

- **Tier 0**: Domain Controllers, AD infrastructure (highest privilege)
- **Tier 1**: Application servers, workloads
- **Tier 2**: End-user workstations (lowest privilege)

The key rule: credentials from a lower tier must **never** authenticate to a higher tier. This prevents lateral movement and credential theft attacks.

## Privileged Access Workstations (PAW)

Tier 0 administration should only be performed from dedicated Privileged Access Workstations that:

- Have no internet access
- Run a hardened OS image
- Are managed by dedicated GPOs
- Use smart card authentication

\`\`\`powershell
# Restrict local administrator group via GPO
$gpo = New-GPO -Name "PAW - Restricted Groups"
Set-GPRegistryValue -Name "PAW - Restricted Groups" \`
  -Key "HKLM\\Software\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon" \`
  -ValueName "DontDisplayLastUserName" -Type DWord -Value 1
\`\`\`

## LAPS Deployment

Local Administrator Password Solution (LAPS) randomizes local admin passwords across all workstations, eliminating pass-the-hash lateral movement.

\`\`\`powershell
# Deploy LAPS via PowerShell
Update-AdmPwdADSchema
Set-AdmPwdComputerSelfPermission -Identity "Workstations"
Set-AdmPwdReadPasswordPermission -Identity "Workstations" -AllowedPrincipals "IT-Helpdesk"
\`\`\`

## Audit Policy Configuration

Enable advanced audit policies to capture authentication events, privilege use, and object access:

\`\`\`powershell
# Configure advanced audit policies
auditpol /set /subcategory:"Logon" /success:enable /failure:enable
auditpol /set /subcategory:"Account Logon" /success:enable /failure:enable
auditpol /set /subcategory:"Kerberos Authentication Service" /success:enable /failure:enable
auditpol /set /subcategory:"Kerberos Service Ticket Operations" /success:enable /failure:enable
\`\`\`

## Key Hardening Checklist

- Disable LM and NTLMv1 authentication
- Enable SMB signing on all machines
- Restrict Anonymous enumeration (RestrictAnonymous = 2)
- Enable Protected Users security group for privileged accounts
- Configure Fine-Grained Password Policies for admin accounts
- Audit and remediate all accounts with AdminSDHolder mismatches
- Review and restrict delegation settings

## Conclusion

Active Directory hardening is an ongoing process, not a one-time project. Regular auditing, privilege reviews, and staying current with threat intelligence are essential to maintaining a secure AD environment.
    `,
  },
  'powershell-automation': {
    title: 'PowerShell Automation for Infrastructure Engineers',
    date: '2026-01-28',
    readTime: '8 min',
    tags: ['PowerShell', 'Automation', 'Infrastructure'],
    content: `
## Introduction

PowerShell is the Swiss Army knife of Windows infrastructure engineering. In this article, I'll share practical automation patterns that have saved hundreds of hours in enterprise environments.

## Bulk User Management

Managing hundreds of user accounts manually is error-prone. Here's a pattern for bulk operations:

\`\`\`powershell
# Bulk import users from CSV
$users = Import-Csv "new-users.csv"
foreach ($user in $users) {
    New-ADUser \`
        -Name "$($user.FirstName) $($user.LastName)" \`
        -GivenName $user.FirstName \`
        -Surname $user.LastName \`
        -SamAccountName $user.Username \`
        -UserPrincipalName "$($user.Username)@contoso.com" \`
        -Department $user.Department \`
        -Enabled $true \`
        -AccountPassword (ConvertTo-SecureString $user.TempPassword -AsPlainText -Force) \`
        -ChangePasswordAtLogon $true
}
\`\`\`

## Automated Reporting

Generate weekly infrastructure health reports automatically:

\`\`\`powershell
# Server health report
$servers = Get-ADComputer -Filter {OperatingSystem -like "*Server*"} | Select -ExpandProperty Name
$report = foreach ($server in $servers) {
    $ping = Test-Connection -ComputerName $server -Count 1 -Quiet
    [PSCustomObject]@{
        Server = $server
        Online = $ping
        LastCheck = Get-Date
    }
}
$report | Export-Csv "server-health-$(Get-Date -Format 'yyyy-MM-dd').csv"
\`\`\`

## Configuration Drift Detection

Detect when server configurations drift from baseline:

\`\`\`powershell
# Compare current state to baseline
$baseline = Import-Csv "baseline-services.csv"
$current = Get-Service | Select Name, Status, StartType

$drift = Compare-Object $baseline $current -Property Name, Status -PassThru
if ($drift) {
    Send-MailMessage -To "it-ops@company.com" \`
        -Subject "Configuration Drift Detected" \`
        -Body ($drift | ConvertTo-Html | Out-String)
}
\`\`\`

## Conclusion

The key to effective PowerShell automation is starting small, testing thoroughly in non-production environments, and building a library of reusable functions. Every repetitive task is an automation opportunity.
    `,
  },
  'enterprise-file-services': {
    title: 'Best Practices for Enterprise File Services',
    date: '2026-01-10',
    readTime: '10 min',
    tags: ['DFS', 'NAS', 'Infrastructure'],
    content: `
## Introduction

Enterprise file services are critical infrastructure that often gets overlooked until something breaks. Here are the best practices I've developed through multiple migration and optimization projects.

## DFS Namespace Design

A well-designed DFS namespace provides location transparency and enables seamless migrations:

\`\`\`powershell
# Create DFS namespace
New-DfsnRoot -Path "\\\\contoso.com\\shared" \`
    -TargetPath "\\\\fileserver01\\shared" \`
    -Type DomainV2

# Add redundant target
New-DfsnRootTarget -Path "\\\\contoso.com\\shared" \`
    -TargetPath "\\\\fileserver02\\shared"
\`\`\`

## Access-Based Enumeration

Enable ABE to hide folders users don't have access to—critical for data governance:

\`\`\`powershell
# Enable ABE on all shares
Get-SmbShare | Set-SmbShare -FolderEnumerationMode AccessBased
\`\`\`

## Storage Tiering Strategy

Implement intelligent tiering to balance performance and cost:

- **Hot tier**: NVMe/SSD for active project files
- **Warm tier**: SAS/SATA for recent archives
- **Cold tier**: Azure Blob / tape for long-term retention

## Conclusion

Good file services architecture requires planning for growth, redundancy, and security from the start. The cost of a poorly designed file system is paid in every migration project that follows.
    `,
  },
}

type Props = {
  params: { slug: string }
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const article = articles[params.slug]
  if (!article) return { title: 'Not Found' }
  return {
    title: `${article.title} | Tapash Chowdhury`,
    description: article.title,
  }
}

export async function generateStaticParams() {
  return Object.keys(articles).map((slug) => ({ slug }))
}

export default function BlogPost({ params }: Props) {
  const article = articles[params.slug]
  if (!article) notFound()

  // Simple markdown-to-HTML conversion
  const renderContent = (content: string) => {
    return content
      .split('\n')
      .map((line) => {
        if (line.startsWith('## ')) return `<h2>${line.slice(3)}</h2>`
        if (line.startsWith('### ')) return `<h3>${line.slice(4)}</h3>`
        if (line.startsWith('- ')) return `<li>${line.slice(2)}</li>`
        if (line.startsWith('**') && line.endsWith('**')) return `<strong>${line.slice(2, -2)}</strong>`
        if (line.trim() === '') return '<br>'
        return `<p>${line}</p>`
      })
      .join('\n')
  }

  return (
    <main className="min-h-screen bg-[#050810] px-6 py-24">
      <div className="max-w-3xl mx-auto">
        {/* Back link */}
        <Link href="/#blog" className="font-mono text-xs text-[#475569] hover:text-[#00a8ff] transition-colors mb-12 inline-flex items-center gap-2">
          ← Back to Blog
        </Link>

        {/* Header */}
        <div className="mb-12">
          <div className="flex flex-wrap gap-2 mb-4 mt-8">
            {article.tags.map((tag) => (
              <span key={tag} className="tech-tag">{tag}</span>
            ))}
          </div>
          <h1 className="text-3xl md:text-4xl font-black text-[#e2e8f0] mb-4 leading-tight">
            {article.title}
          </h1>
          <div className="flex gap-6 font-mono text-xs text-[#334155]">
            <span>{article.date}</span>
            <span>// {article.readTime} read</span>
          </div>
        </div>

        {/* Divider */}
        <div className="h-px bg-gradient-to-r from-[rgba(0,168,255,0.4)] via-[rgba(0,255,157,0.2)] to-transparent mb-12" />

        {/* Content */}
        <div
          className="prose-cyber"
          dangerouslySetInnerHTML={{ __html: renderContent(article.content) }}
        />

        {/* Footer */}
        <div className="mt-16 pt-8 border-t border-[rgba(255,255,255,0.05)]">
          <Link href="/#blog" className="btn-outline text-xs">
            ← More Articles
          </Link>
        </div>
      </div>
    </main>
  )
}

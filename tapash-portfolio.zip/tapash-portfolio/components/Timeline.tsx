'use client'

import { motion, useInView } from 'framer-motion'
import { useRef } from 'react'

const experiences = [
  {
    company: 'Stelogy',
    role: 'Network & Systems Engineer',
    period: '2022 – Present',
    location: 'Enterprise Production',
    current: true,
    responsibilities: [
      'Infrastructure operations and maintenance across multi-site enterprise environments',
      'Active Directory security hardening and identity governance',
      'Enterprise data migration projects (on-prem to NAS / hybrid cloud)',
      'Fortinet network security management and firewall policy design',
      'Incident management and root cause analysis',
      'Infrastructure automation development with PowerShell',
      'Microsoft 365 administration and Teams governance',
      'Backup and disaster recovery planning and execution',
    ],
    tech: ['Windows Server', 'Active Directory', 'Azure', 'Fortinet', 'PowerShell', 'DFS', 'M365'],
  },
]

export default function Timeline() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: '-100px' })

  return (
    <section id="experience" className="relative py-32 px-6">
      <div className="absolute inset-0 grid-bg opacity-20" />

      <div className="max-w-7xl mx-auto relative" ref={ref}>
        {/* Section label */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={isInView ? { opacity: 1, x: 0 } : {}}
          className="flex items-center gap-4 mb-4"
        >
          <span className="section-label">06 // Experience</span>
          <div className="h-px flex-1 max-w-xs bg-gradient-to-r from-[rgba(0,255,157,0.4)] to-transparent" />
        </motion.div>

        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.1 }}
          className="text-4xl md:text-5xl font-black mb-16"
        >
          Work <span className="gradient-text-green">Experience</span>
        </motion.h2>

        {/* Timeline */}
        <div className="relative">
          {/* Vertical line */}
          <div className="absolute left-6 md:left-8 top-0 bottom-0 w-px bg-gradient-to-b from-[rgba(0,168,255,0.5)] via-[rgba(0,168,255,0.3)] to-transparent" />

          {experiences.map((exp, i) => (
            <motion.div
              key={exp.company}
              initial={{ opacity: 0, x: -30 }}
              animate={isInView ? { opacity: 1, x: 0 } : {}}
              transition={{ duration: 0.8, delay: i * 0.15 }}
              className="relative pl-16 md:pl-24 mb-12"
            >
              {/* Timeline node */}
              <div className="absolute left-4 md:left-6 top-6 -translate-x-1/2 w-4 h-4 border-2 border-[#00a8ff] bg-[#050810]"
                style={{ boxShadow: '0 0 10px rgba(0,168,255,0.5)' }}>
                {exp.current && (
                  <div className="absolute inset-0.5 bg-[#00ff9d] animate-pulse" />
                )}
              </div>

              <div className="cyber-border bg-[rgba(10,15,30,0.8)] p-8">
                {/* Top accent */}
                <div className="h-px w-full mb-8 bg-gradient-to-r from-[rgba(0,168,255,0.4)] via-[rgba(0,255,157,0.2)] to-transparent" />

                {/* Header */}
                <div className="flex flex-wrap items-start justify-between gap-4 mb-6">
                  <div>
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="text-2xl md:text-3xl font-black text-[#e2e8f0]">{exp.company}</h3>
                      {exp.current && (
                        <span className="font-mono text-[10px] px-2 py-1 bg-[rgba(0,255,157,0.1)] border border-[rgba(0,255,157,0.3)] text-[#00ff9d] tracking-widest">
                          CURRENT
                        </span>
                      )}
                    </div>
                    <div className="gradient-text-blue font-bold text-lg">{exp.role}</div>
                  </div>

                  <div className="text-right">
                    <div className="font-mono text-sm text-[#475569] mb-1">{exp.period}</div>
                    <div className="font-mono text-xs text-[#334155]">{exp.location}</div>
                  </div>
                </div>

                {/* Responsibilities */}
                <div className="mb-8">
                  <h4 className="font-mono text-xs tracking-widest text-[#475569] uppercase mb-4">// Responsibilities</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {exp.responsibilities.map((item) => (
                      <div key={item} className="flex items-start gap-2">
                        <span className="text-[#00ff9d] font-mono text-xs mt-1 flex-shrink-0">▸</span>
                        <span className="text-[#94a3b8] text-sm">{item}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Tech stack */}
                <div>
                  <h4 className="font-mono text-xs tracking-widest text-[#475569] uppercase mb-3">// Technologies</h4>
                  <div className="flex flex-wrap gap-2">
                    {exp.tech.map((t) => (
                      <span key={t} className="tech-tag">{t}</span>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

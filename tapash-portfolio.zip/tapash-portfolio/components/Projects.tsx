'use client'

import { motion, useInView } from 'framer-motion'
import { useRef, useState } from 'react'

const projects = [
  {
    id: 1,
    title: 'Enterprise File Services Migration',
    category: 'Infrastructure',
    status: 'Delivered',
    description: 'End-to-end migration of enterprise file services from aging on-prem infrastructure to a hybrid NAS and cloud storage architecture. Reduced storage costs by 40% while improving redundancy and access performance.',
    longDesc: [
      'Migrated 8TB+ of production data with zero downtime using DFS namespaces',
      'Implemented tiered storage with hot/cold archival policies',
      'Automated migration workflows using PowerShell scripts',
      'Established new backup and disaster recovery procedures',
    ],
    tech: ['Windows Server', 'DFS', 'PowerShell', 'NAS', 'Azure Blob'],
    color: '#00a8ff',
    icon: '🗄',
  },
  {
    id: 2,
    title: 'Active Directory Security Hardening',
    category: 'Security',
    status: 'Delivered',
    description: 'Comprehensive security hardening of enterprise Active Directory, implementing least-privilege access model, tiered administration, and continuous security auditing across thousands of user accounts.',
    longDesc: [
      'Implemented three-tier administrative model (T0/T1/T2)',
      'Audited and remediated 500+ over-privileged accounts',
      'Deployed LAPS for local administrator password management',
      'Configured advanced audit policies and SIEM integration',
    ],
    tech: ['Active Directory', 'PowerShell', 'Group Policy', 'LAPS', 'SIEM'],
    color: '#00ff9d',
    icon: '🔒',
  },
  {
    id: 3,
    title: 'Cloud Infrastructure Lab',
    category: 'Cloud',
    status: 'Ongoing',
    description: 'Personal homelab environment replicating enterprise architecture for testing infrastructure automation, security monitoring, and cloud integration patterns before production deployment.',
    longDesc: [
      'Azure hybrid connectivity with VPN gateway',
      'Automated provisioning with PowerShell DSC',
      'Security monitoring with Fortinet + centralized logging',
      'Kubernetes cluster for container workload testing',
    ],
    tech: ['Azure', 'Kubernetes', 'Fortinet', 'PowerShell', 'Terraform'],
    color: '#0047ff',
    icon: '🏗',
  },
  {
    id: 4,
    title: 'Fortinet Network Segmentation',
    category: 'Security',
    status: 'Delivered',
    description: 'Designed and implemented network segmentation across enterprise sites using Fortinet FortiGate firewalls, creating isolated security zones for different business units and reducing attack surface.',
    longDesc: [
      'Implemented VLAN-based network segmentation across 3 sites',
      'Configured inter-VLAN routing policies with strict ACLs',
      'Deployed IPS/IDS policies and web filtering',
      'Established site-to-site VPN with SD-WAN failover',
    ],
    tech: ['FortiGate', 'FortiOS', 'SD-WAN', 'VLAN', 'IPSec VPN'],
    color: '#ff6b35',
    icon: '🔥',
  },
]

const filters = ['All', 'Infrastructure', 'Security', 'Cloud']

function ProjectCard({ project, index }: { project: typeof projects[0]; index: number }) {
  const [expanded, setExpanded] = useState(false)
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: '-50px' })

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 40 }}
      animate={isInView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.7, delay: index * 0.12 }}
      className="cyber-border card-hover bg-[rgba(10,15,30,0.7)] backdrop-blur-sm overflow-hidden group cursor-pointer"
      onClick={() => setExpanded(!expanded)}
    >
      {/* Top accent line */}
      <div className="h-px w-full" style={{ background: `linear-gradient(90deg, transparent, ${project.color}, transparent)` }} />

      <div className="p-8">
        {/* Header */}
        <div className="flex items-start justify-between gap-4 mb-6">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 flex items-center justify-center text-2xl border"
              style={{ borderColor: `${project.color}33`, background: `${project.color}08` }}>
              {project.icon}
            </div>
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="font-mono text-xs px-2 py-0.5 rounded"
                  style={{ background: `${project.color}15`, color: project.color, border: `1px solid ${project.color}33` }}>
                  {project.category}
                </span>
                <span className={`font-mono text-xs px-2 py-0.5 rounded ${
                  project.status === 'Ongoing'
                    ? 'bg-[rgba(0,255,157,0.1)] text-[#00ff9d] border border-[rgba(0,255,157,0.2)]'
                    : 'bg-[rgba(100,116,139,0.1)] text-[#64748b] border border-[rgba(100,116,139,0.2)]'
                }`}>
                  {project.status}
                </span>
              </div>
              <h3 className="text-xl font-bold text-[#e2e8f0] group-hover:text-white transition-colors">
                {project.title}
              </h3>
            </div>
          </div>

          {/* Architecture placeholder */}
          <div className="hidden md:flex w-24 h-16 border border-[rgba(255,255,255,0.05)] bg-[rgba(0,0,0,0.3)] items-center justify-center flex-shrink-0">
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke={`${project.color}60`} strokeWidth="1">
              <rect x="2" y="3" width="8" height="5" rx="1"/>
              <rect x="14" y="3" width="8" height="5" rx="1"/>
              <rect x="7" y="14" width="10" height="5" rx="1"/>
              <path d="M6 8v2M18 8v2M10 11h4M12 11v3"/>
            </svg>
          </div>
        </div>

        {/* Description */}
        <p className="text-[#64748b] text-sm leading-relaxed mb-6">{project.description}</p>

        {/* Expanded details */}
        <motion.div
          initial={false}
          animate={{ height: expanded ? 'auto' : 0, opacity: expanded ? 1 : 0 }}
          transition={{ duration: 0.3 }}
          style={{ overflow: 'hidden' }}
        >
          <div className="mb-6 border-t border-[rgba(255,255,255,0.05)] pt-6">
            <h4 className="font-mono text-xs text-[#475569] tracking-widest uppercase mb-3">// Key Deliverables</h4>
            <ul className="space-y-2">
              {project.longDesc.map((item) => (
                <li key={item} className="flex items-start gap-2 text-sm text-[#94a3b8]">
                  <span style={{ color: project.color }} className="mt-0.5 flex-shrink-0">▸</span>
                  {item}
                </li>
              ))}
            </ul>
          </div>
        </motion.div>

        {/* Tech stack */}
        <div className="flex items-center justify-between">
          <div className="flex flex-wrap gap-2">
            {project.tech.map((t) => (
              <span key={t} className="tech-tag">{t}</span>
            ))}
          </div>
          <button className="font-mono text-xs text-[#475569] hover:text-[#00a8ff] transition-colors ml-4 flex-shrink-0">
            {expanded ? '[ collapse ]' : '[ expand ]'}
          </button>
        </div>
      </div>
    </motion.div>
  )
}

export default function Projects() {
  const [activeFilter, setActiveFilter] = useState('All')
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: '-100px' })

  const filtered = activeFilter === 'All'
    ? projects
    : projects.filter((p) => p.category === activeFilter)

  return (
    <section id="projects" className="relative py-32 px-6">
      <div className="absolute inset-0 grid-bg opacity-30" />

      <div className="max-w-7xl mx-auto relative" ref={ref}>
        {/* Section label */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={isInView ? { opacity: 1, x: 0 } : {}}
          className="flex items-center gap-4 mb-4"
        >
          <span className="section-label">03 // Projects</span>
          <div className="h-px flex-1 max-w-xs bg-gradient-to-r from-[rgba(0,255,157,0.4)] to-transparent" />
        </motion.div>

        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.1 }}
          className="text-4xl md:text-5xl font-black mb-4"
        >
          Featured <span className="gradient-text-blue">Projects</span>
        </motion.h2>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.15 }}
          className="text-[#475569] max-w-xl mb-10"
        >
          Enterprise infrastructure and security projects delivered in production environments.
        </motion.p>

        {/* Filters */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.2 }}
          className="flex flex-wrap gap-2 mb-12"
        >
          {filters.map((f) => (
            <button
              key={f}
              onClick={() => setActiveFilter(f)}
              className={`font-mono text-xs px-4 py-2 border transition-all ${
                activeFilter === f
                  ? 'border-[#00a8ff] text-[#00a8ff] bg-[rgba(0,168,255,0.08)]'
                  : 'border-[rgba(255,255,255,0.08)] text-[#475569] hover:border-[rgba(0,168,255,0.3)] hover:text-[#00a8ff]'
              }`}
            >
              {f}
            </button>
          ))}
        </motion.div>

        {/* Projects grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {filtered.map((project, i) => (
            <ProjectCard key={project.id} project={project} index={i} />
          ))}
        </div>
      </div>
    </section>
  )
}

'use client'

import { motion, useInView } from 'framer-motion'
import { useRef, useState } from 'react'

const articles = [
  {
    slug: 'securing-active-directory',
    title: 'Securing Active Directory in Enterprise Environments',
    excerpt: 'A comprehensive guide to hardening Active Directory against modern attack vectors — from Kerberoasting to pass-the-hash attacks. Covers tiered admin models, LAPS deployment, and audit policy configuration.',
    date: '2026-02-15',
    readTime: '12 min',
    tags: ['Active Directory', 'Security', 'Windows'],
    featured: true,
  },
  {
    slug: 'powershell-automation',
    title: 'PowerShell Automation for Infrastructure Engineers',
    excerpt: 'Practical automation patterns for enterprise infrastructure: bulk user management, automated reporting, configuration drift detection, and scheduled maintenance tasks.',
    date: '2026-01-28',
    readTime: '8 min',
    tags: ['PowerShell', 'Automation', 'Infrastructure'],
    featured: false,
  },
  {
    slug: 'enterprise-file-services',
    title: 'Best Practices for Enterprise File Services',
    excerpt: 'DFS namespace design, tiered storage strategies, quota management, and access-based enumeration. Everything you need to build a scalable enterprise file services architecture.',
    date: '2026-01-10',
    readTime: '10 min',
    tags: ['DFS', 'NAS', 'Infrastructure'],
    featured: false,
  },
  {
    slug: 'hybrid-cloud-smb',
    title: 'Hybrid Cloud Architecture for SMB',
    excerpt: 'Practical guide to extending on-premises infrastructure to Azure for small and medium businesses — identity federation, hybrid storage, and cost optimization strategies.',
    date: '2025-12-20',
    readTime: '14 min',
    tags: ['Azure', 'Hybrid Cloud', 'Architecture'],
    featured: false,
  },
  {
    slug: 'fortinet-hardening',
    title: 'Fortinet Firewall Hardening Guide',
    excerpt: 'Step-by-step FortiGate hardening: securing management access, configuring IPS/IDS profiles, implementing web filtering, and establishing SD-WAN policies for resilient connectivity.',
    date: '2025-12-05',
    readTime: '11 min',
    tags: ['Fortinet', 'Firewall', 'Network Security'],
    featured: false,
  },
]

function ArticleCard({ article, index, featured }: { article: typeof articles[0]; index: number; featured?: boolean }) {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: '-30px' })

  const tagColors: Record<string, string> = {
    'Active Directory': '#00ff9d',
    'Security': '#ff6b35',
    'Windows': '#00a8ff',
    'PowerShell': '#00a8ff',
    'Automation': '#00ff9d',
    'Infrastructure': '#0047ff',
    'DFS': '#00a8ff',
    'NAS': '#00ff9d',
    'Azure': '#00a8ff',
    'Hybrid Cloud': '#0047ff',
    'Architecture': '#00ff9d',
    'Fortinet': '#ff6b35',
    'Firewall': '#ff6b35',
    'Network Security': '#00a8ff',
  }

  if (featured) {
    return (
      <motion.div
        ref={ref}
        initial={{ opacity: 0, y: 30 }}
        animate={isInView ? { opacity: 1, y: 0 } : {}}
        transition={{ duration: 0.7 }}
        className="col-span-full cyber-border card-hover bg-[rgba(10,15,30,0.8)] p-8 relative overflow-hidden group"
      >
        {/* Featured label */}
        <div className="absolute top-0 right-0 font-mono text-[10px] tracking-widest px-4 py-2 bg-[rgba(0,168,255,0.1)] border-b border-l border-[rgba(0,168,255,0.2)] text-[#00a8ff]">
          FEATURED
        </div>

        <div className="flex items-start gap-6">
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-4">
              {article.tags.map((tag) => (
                <span key={tag} className="font-mono text-[10px] tracking-widest uppercase"
                  style={{ color: tagColors[tag] || '#00a8ff' }}>
                  #{tag.toLowerCase().replace(' ', '-')}
                </span>
              ))}
            </div>
            <h3 className="text-2xl md:text-3xl font-black text-[#e2e8f0] group-hover:text-white mb-3 transition-colors">
              {article.title}
            </h3>
            <p className="text-[#64748b] leading-relaxed mb-6 max-w-2xl">{article.excerpt}</p>
            <div className="flex items-center gap-6">
              <span className="font-mono text-xs text-[#334155]">{article.date}</span>
              <span className="font-mono text-xs text-[#334155]">// {article.readTime} read</span>
              <a href={`/blog/${article.slug}`}
                className="font-mono text-xs text-[#00a8ff] hover:text-white transition-colors flex items-center gap-2">
                Read Article
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M5 12h14M12 5l7 7-7 7"/>
                </svg>
              </a>
            </div>
          </div>
        </div>
      </motion.div>
    )
  }

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 30 }}
      animate={isInView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.6, delay: index * 0.08 }}
      className="cyber-border card-hover bg-[rgba(10,15,30,0.6)] p-6 group"
    >
      <div className="flex flex-wrap gap-2 mb-3">
        {article.tags.map((tag) => (
          <span key={tag} className="font-mono text-[10px] tracking-widest uppercase"
            style={{ color: tagColors[tag] || '#00a8ff' }}>
            #{tag.toLowerCase().replace(' ', '-')}
          </span>
        ))}
      </div>
      <h3 className="text-base font-bold text-[#e2e8f0] group-hover:text-[#00a8ff] mb-2 transition-colors leading-snug">
        {article.title}
      </h3>
      <p className="text-[#475569] text-sm leading-relaxed mb-4 line-clamp-2">{article.excerpt}</p>
      <div className="flex items-center justify-between">
        <div className="flex gap-4">
          <span className="font-mono text-[10px] text-[#334155]">{article.date}</span>
          <span className="font-mono text-[10px] text-[#334155]">{article.readTime}</span>
        </div>
        <a href={`/blog/${article.slug}`}
          className="font-mono text-[10px] text-[#475569] group-hover:text-[#00a8ff] transition-colors">
          Read →
        </a>
      </div>
    </motion.div>
  )
}

export default function BlogSection() {
  const [search, setSearch] = useState('')
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: '-100px' })

  const filtered = articles.filter((a) =>
    a.title.toLowerCase().includes(search.toLowerCase()) ||
    a.tags.some((t) => t.toLowerCase().includes(search.toLowerCase()))
  )

  return (
    <section id="blog" className="relative py-32 px-6">
      <div className="max-w-7xl mx-auto" ref={ref}>
        {/* Section label */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={isInView ? { opacity: 1, x: 0 } : {}}
          className="flex items-center gap-4 mb-4"
        >
          <span className="section-label">04 // Blog</span>
          <div className="h-px flex-1 max-w-xs bg-gradient-to-r from-[rgba(0,255,157,0.4)] to-transparent" />
        </motion.div>

        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.1 }}
          className="text-4xl md:text-5xl font-black mb-4"
        >
          Technical <span className="gradient-text-green">Writing</span>
        </motion.h2>

        {/* Search */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.15 }}
          className="mb-12 flex items-center gap-4"
        >
          <div className="relative max-w-sm">
            <input
              type="text"
              placeholder="Search articles..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full bg-[rgba(10,15,30,0.8)] border border-[rgba(0,168,255,0.15)] px-4 py-2.5 pl-10 font-mono text-sm text-[#94a3b8] placeholder-[#334155] focus:outline-none focus:border-[rgba(0,168,255,0.5)] transition-colors"
            />
            <svg className="absolute left-3 top-1/2 -translate-y-1/2 text-[#334155]" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
            </svg>
          </div>
          <span className="font-mono text-xs text-[#334155]">{filtered.length} articles</span>
        </motion.div>

        {/* Articles grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filtered.map((article, i) => (
            <ArticleCard
              key={article.slug}
              article={article}
              index={i}
              featured={article.featured}
            />
          ))}
        </div>
      </div>
    </section>
  )
}

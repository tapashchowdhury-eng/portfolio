'use client'

import { motion, useInView } from 'framer-motion'
import { useRef } from 'react'

const certifications = [
  {
    title: 'Fortinet FortiGate Administrator',
    version: 'v7.6',
    issuer: 'Fortinet',
    badge: 'NSE',
    color: '#ff6b35',
    icon: '🔥',
    year: '2024',
    desc: 'FortiGate administration, policy configuration, VPN, and security profiles.',
  },
  {
    title: 'Containers & Kubernetes Essentials',
    version: 'CKE',
    issuer: 'IBM / Coursera',
    badge: 'CKE',
    color: '#00a8ff',
    icon: '⚓',
    year: '2024',
    desc: 'Container fundamentals, Kubernetes architecture, deployment, and orchestration.',
  },
  {
    title: 'Microsoft 365 Teams Administrator',
    version: 'MS-700',
    issuer: 'Microsoft',
    badge: 'MS',
    color: '#0078d4',
    icon: '🪟',
    year: '2023',
    desc: 'Teams deployment, governance, security, and compliance configuration.',
  },
  {
    title: 'NSE Network Security Associate',
    version: 'NSE 1-2',
    issuer: 'Fortinet NSE Institute',
    badge: 'NSE',
    color: '#00ff9d',
    icon: '🛡',
    year: '2023',
    desc: 'Foundational network security concepts and threat landscape knowledge.',
  },
]

export default function Certifications() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: '-100px' })

  return (
    <section id="certifications" className="relative py-32 px-6">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[rgba(0,0,0,0.3)] to-transparent" />

      <div className="max-w-7xl mx-auto relative" ref={ref}>
        {/* Section label */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={isInView ? { opacity: 1, x: 0 } : {}}
          className="flex items-center gap-4 mb-4"
        >
          <span className="section-label">05 // Certifications</span>
          <div className="h-px flex-1 max-w-xs bg-gradient-to-r from-[rgba(0,255,157,0.4)] to-transparent" />
        </motion.div>

        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.1 }}
          className="text-4xl md:text-5xl font-black mb-16"
        >
          Credentials &amp; <span className="gradient-text-blue">Certs</span>
        </motion.h2>

        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
          {certifications.map((cert, i) => (
            <motion.div
              key={cert.title}
              initial={{ opacity: 0, y: 40 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: i * 0.1 }}
              className="cyber-border card-hover bg-[rgba(10,15,30,0.8)] p-6 relative overflow-hidden group"
            >
              {/* Background glow */}
              <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                style={{ background: `radial-gradient(ellipse at top, ${cert.color}08, transparent)` }} />

              {/* Top border accent */}
              <div className="absolute top-0 left-0 right-0 h-px"
                style={{ background: `linear-gradient(90deg, transparent, ${cert.color}60, transparent)` }} />

              {/* Badge */}
              <div className="w-14 h-14 flex items-center justify-center text-2xl border mb-6 relative"
                style={{ borderColor: `${cert.color}40`, background: `${cert.color}08` }}>
                {cert.icon}
                <div className="absolute -top-1 -right-1 w-4 h-4 flex items-center justify-center"
                  style={{ background: cert.color }}>
                  <span className="text-black font-mono font-black text-[8px]">✓</span>
                </div>
              </div>

              <h3 className="font-bold text-[#e2e8f0] leading-tight mb-1">{cert.title}</h3>
              <div className="font-mono text-xs mb-3" style={{ color: cert.color }}>{cert.version}</div>
              <p className="text-[#475569] text-xs leading-relaxed mb-4">{cert.desc}</p>

              <div className="flex items-center justify-between">
                <span className="font-mono text-[10px] text-[#334155]">{cert.issuer}</span>
                <span className="font-mono text-[10px] text-[#334155]">{cert.year}</span>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

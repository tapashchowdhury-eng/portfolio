'use client'

import { useEffect, useRef } from 'react'
import { motion } from 'framer-motion'

function ParticleCanvas() {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    canvas.width = window.innerWidth
    canvas.height = window.innerHeight

    const particles: Array<{
      x: number; y: number; vx: number; vy: number; size: number; opacity: number
    }> = []

    const PARTICLE_COUNT = 80
    for (let i = 0; i < PARTICLE_COUNT; i++) {
      particles.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        vx: (Math.random() - 0.5) * 0.4,
        vy: (Math.random() - 0.5) * 0.4,
        size: Math.random() * 2 + 0.5,
        opacity: Math.random() * 0.5 + 0.1,
      })
    }

    const CONNECTION_DIST = 140

    function draw() {
      if (!ctx || !canvas) return
      ctx.clearRect(0, 0, canvas.width, canvas.height)

      // Update & draw particles
      for (let i = 0; i < particles.length; i++) {
        const p = particles[i]
        p.x += p.vx
        p.y += p.vy
        if (p.x < 0 || p.x > canvas.width) p.vx *= -1
        if (p.y < 0 || p.y > canvas.height) p.vy *= -1

        ctx.beginPath()
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2)
        ctx.fillStyle = `rgba(0, 168, 255, ${p.opacity})`
        ctx.fill()

        // Connect nearby particles
        for (let j = i + 1; j < particles.length; j++) {
          const p2 = particles[j]
          const dx = p.x - p2.x
          const dy = p.y - p2.y
          const dist = Math.sqrt(dx * dx + dy * dy)

          if (dist < CONNECTION_DIST) {
            const alpha = (1 - dist / CONNECTION_DIST) * 0.15
            ctx.beginPath()
            ctx.moveTo(p.x, p.y)
            ctx.lineTo(p2.x, p2.y)
            ctx.strokeStyle = `rgba(0, 168, 255, ${alpha})`
            ctx.lineWidth = 0.5
            ctx.stroke()
          }
        }
      }

      requestAnimationFrame(draw)
    }

    draw()

    const handleResize = () => {
      canvas.width = window.innerWidth
      canvas.height = window.innerHeight
    }
    window.addEventListener('resize', handleResize)
    return () => window.removeEventListener('resize', handleResize)
  }, [])

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 w-full h-full"
      style={{ opacity: 0.7 }}
    />
  )
}

const containerVariants = {
  hidden: {},
  visible: { transition: { staggerChildren: 0.12 } },
}

const itemVariants = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.8, ease: [0.4, 0, 0.2, 1] } },
}

export default function Hero() {
  return (
    <section
      id="home"
      className="relative min-h-screen flex items-center justify-center overflow-hidden grid-bg"
    >
      {/* Background layers */}
      <div className="absolute inset-0 bg-gradient-radial from-[rgba(0,71,255,0.08)] via-transparent to-transparent" />
      <div className="absolute bottom-0 left-0 right-0 h-64 bg-gradient-to-t from-[#050810] to-transparent" />
      
      {/* Animated glow orbs */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full bg-[rgba(0,168,255,0.04)] blur-3xl animate-pulse-slow" />
      <div className="absolute bottom-1/3 right-1/4 w-64 h-64 rounded-full bg-[rgba(0,255,157,0.04)] blur-3xl animate-pulse-slow" style={{ animationDelay: '2s' }} />

      {/* Network particles */}
      <ParticleCanvas />

      {/* Corner decorations */}
      <div className="absolute top-20 left-8 w-16 h-16 border-t border-l border-[rgba(0,255,157,0.3)]" />
      <div className="absolute top-20 right-8 w-16 h-16 border-t border-r border-[rgba(0,255,157,0.3)]" />
      <div className="absolute bottom-20 left-8 w-16 h-16 border-b border-l border-[rgba(0,168,255,0.3)]" />
      <div className="absolute bottom-20 right-8 w-16 h-16 border-b border-r border-[rgba(0,168,255,0.3)]" />

      {/* Content */}
      <div className="relative z-10 max-w-5xl mx-auto px-6 text-center">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          {/* Status badge */}
          <motion.div variants={itemVariants} className="mb-8 flex justify-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-[rgba(0,255,157,0.2)] bg-[rgba(0,255,157,0.05)]">
              <span className="w-2 h-2 rounded-full bg-[#00ff9d] animate-pulse" />
              <span className="font-mono text-xs text-[#00ff9d] tracking-widest uppercase">
                Available for new opportunities
              </span>
            </div>
          </motion.div>

          {/* Name */}
          <motion.div variants={itemVariants}>
            <h1 className="text-6xl md:text-8xl font-display font-black tracking-tight mb-4">
              <span className="text-[#e2e8f0]">Tapash </span>
              <span className="gradient-text-blue">Chowdhury</span>
            </h1>
          </motion.div>

          {/* Title */}
          <motion.div variants={itemVariants} className="mb-6">
            <div className="inline-flex items-center gap-3">
              <div className="h-px w-12 bg-gradient-to-r from-transparent to-[#00ff9d]" />
              <span className="font-mono text-sm md:text-base tracking-[0.3em] text-[#00ff9d] uppercase">
                Cloud & Security Engineer
              </span>
              <div className="h-px w-12 bg-gradient-to-l from-transparent to-[#00ff9d]" />
            </div>
          </motion.div>

          {/* Tagline */}
          <motion.p
            variants={itemVariants}
            className="text-lg md:text-xl text-[#64748b] max-w-2xl mx-auto mb-12 leading-relaxed"
          >
            Designing{' '}
            <span className="text-[#00a8ff]">secure cloud infrastructure</span>,
            automation and{' '}
            <span className="text-[#00ff9d]">resilient systems</span>.
          </motion.p>

          {/* Buttons */}
          <motion.div variants={itemVariants} className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <a href="#projects" className="btn-primary">
              <span className="flex items-center gap-2">
                <span>View Projects</span>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M5 12h14M12 5l7 7-7 7"/>
                </svg>
              </span>
            </a>
            <a href="#blog" className="btn-outline">Read Blog</a>
            <a href="#contact" className="btn-outline">Contact</a>
          </motion.div>

          {/* Stats */}
          <motion.div
            variants={itemVariants}
            className="mt-20 grid grid-cols-3 gap-8 max-w-md mx-auto"
          >
            {[
              { label: 'Years Experience', value: '3+' },
              { label: 'Projects Delivered', value: '20+' },
              { label: 'Certifications', value: '4' },
            ].map((stat) => (
              <div key={stat.label} className="text-center">
                <div className="text-3xl font-black gradient-text-blue mb-1">{stat.value}</div>
                <div className="font-mono text-[10px] text-[#475569] tracking-widest uppercase">{stat.label}</div>
              </div>
            ))}
          </motion.div>
        </motion.div>

        {/* Scroll indicator */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 2, duration: 1 }}
          className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2"
        >
          <span className="font-mono text-[10px] text-[#334155] tracking-widest uppercase">Scroll</span>
          <div className="w-px h-12 bg-gradient-to-b from-[#00a8ff] to-transparent" />
        </motion.div>
      </div>
    </section>
  )
}

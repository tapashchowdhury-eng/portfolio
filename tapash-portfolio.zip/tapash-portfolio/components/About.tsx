'use client'

import { motion } from 'framer-motion'
import { useInView } from 'framer-motion'
import { useRef } from 'react'

const specialties = [
  'Windows Infrastructure',
  'Active Directory Security',
  'Cloud Architecture',
  'Infrastructure Automation',
  'Identity & Access Management',
  'Enterprise File Services',
  'Incident Response',
]

export default function About() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: '-100px' })

  return (
    <section id="about" className="relative py-32 px-6 overflow-hidden">
      {/* Background accent */}
      <div className="absolute top-0 right-0 w-1/2 h-px bg-gradient-to-l from-transparent via-[rgba(0,168,255,0.2)] to-transparent" />
      <div className="absolute bottom-0 left-0 w-1/2 h-px bg-gradient-to-r from-transparent via-[rgba(0,255,157,0.2)] to-transparent" />

      <div className="max-w-7xl mx-auto" ref={ref}>
        {/* Section label */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={isInView ? { opacity: 1, x: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="flex items-center gap-4 mb-16"
        >
          <span className="section-label">01 // About</span>
          <div className="h-px flex-1 max-w-xs bg-gradient-to-r from-[rgba(0,255,157,0.4)] to-transparent" />
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          {/* Photo placeholder */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={isInView ? { opacity: 1, scale: 1 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative"
          >
            <div className="relative w-full max-w-sm mx-auto">
              {/* Photo frame */}
              <div className="relative bg-[#0a0f1e] border border-[rgba(0,168,255,0.15)] overflow-hidden"
                style={{ aspectRatio: '3/4' }}>
                {/* Placeholder content */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center">
                    <div className="w-24 h-24 rounded-full bg-gradient-to-br from-[rgba(0,168,255,0.3)] to-[rgba(0,255,157,0.1)] mx-auto mb-4 flex items-center justify-center border border-[rgba(0,168,255,0.2)]">
                      <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="rgba(0,168,255,0.6)" strokeWidth="1.5">
                        <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
                        <circle cx="12" cy="7" r="4"/>
                      </svg>
                    </div>
                    <span className="font-mono text-xs text-[#334155] tracking-widest">PHOTO</span>
                  </div>
                </div>
                
                {/* Grid overlay */}
                <div className="absolute inset-0 grid-bg opacity-30" />
                
                {/* Corner decorations */}
                <div className="absolute top-4 left-4 w-8 h-8 border-t border-l border-[rgba(0,255,157,0.4)]" />
                <div className="absolute bottom-4 right-4 w-8 h-8 border-b border-r border-[rgba(0,255,157,0.4)]" />
                
                {/* Scan line animation */}
                <div className="absolute left-0 right-0 h-px bg-gradient-to-r from-transparent via-[rgba(0,168,255,0.4)] to-transparent"
                  style={{ animation: 'scan 4s linear infinite' }} />
              </div>

              {/* Decorative elements */}
              <div className="absolute -bottom-4 -right-4 w-32 h-32 border border-[rgba(0,168,255,0.1)] -z-10" />
              <div className="absolute -top-4 -left-4 w-24 h-24 border border-[rgba(0,255,157,0.08)] -z-10" />

              {/* Status card */}
              <div className="absolute -bottom-6 -left-6 bg-[#0a0f1e] border border-[rgba(0,168,255,0.2)] px-4 py-3">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-[#00ff9d] animate-pulse" />
                  <span className="font-mono text-xs text-[#00ff9d]">Active @ Stelogy</span>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Content */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.3 }}
          >
            <h2 className="text-4xl md:text-5xl font-black mb-6">
              Network & Systems<br />
              <span className="gradient-text-blue">Engineer</span>
            </h2>

            <p className="text-[#64748b] leading-relaxed mb-8 text-base">
              Tapash Chowdhury is a Network & Systems Engineer specialized in{' '}
              <span className="text-[#00a8ff]">cloud infrastructure</span>,{' '}
              <span className="text-[#00ff9d]">cybersecurity</span> and{' '}
              automation. He works on enterprise production environments, building
              resilient, secure systems that scale.
            </p>

            {/* Specialties */}
            <div className="mb-8">
              <h3 className="font-mono text-xs tracking-widest text-[#475569] uppercase mb-4">
                // Focus Areas
              </h3>
              <div className="space-y-2">
                {specialties.map((item, i) => (
                  <motion.div
                    key={item}
                    initial={{ opacity: 0, x: -10 }}
                    animate={isInView ? { opacity: 1, x: 0 } : {}}
                    transition={{ delay: 0.4 + i * 0.06 }}
                    className="flex items-center gap-3"
                  >
                    <span className="text-[#00ff9d] font-mono text-xs">▸</span>
                    <span className="text-[#94a3b8] text-sm">{item}</span>
                  </motion.div>
                ))}
              </div>
            </div>

            {/* Links */}
            <div className="flex gap-4">
              <a
                href="https://www.linkedin.com/in/tapash-chowdhury75/"
                target="_blank"
                rel="noopener noreferrer"
                className="btn-primary text-xs"
              >
                LinkedIn Profile
              </a>
              <a href="#projects" className="btn-outline text-xs">View Work</a>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}

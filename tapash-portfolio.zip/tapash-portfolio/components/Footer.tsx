'use client'

import { motion } from 'framer-motion'

export default function Footer() {
  return (
    <footer className="relative border-t border-[rgba(0,168,255,0.08)] py-12 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          {/* Logo & name */}
          <div className="flex items-center gap-4">
            <div className="w-8 h-8 border border-[rgba(0,255,157,0.4)] flex items-center justify-center">
              <div className="w-3 h-3 bg-[#00ff9d] opacity-80" />
            </div>
            <div>
              <div className="font-display font-bold text-[#e2e8f0]">Tapash Chowdhury</div>
              <div className="font-mono text-xs text-[#475569]">Cloud &amp; Security Engineer</div>
            </div>
          </div>

          {/* Center links */}
          <div className="flex gap-6">
            {['#about', '#projects', '#blog', '#contact'].map((href) => (
              <a
                key={href}
                href={href}
                className="font-mono text-xs text-[#334155] hover:text-[#00a8ff] transition-colors uppercase tracking-widest"
              >
                {href.replace('#', '')}
              </a>
            ))}
          </div>

          {/* Copyright */}
          <div className="font-mono text-xs text-[#334155]">
            © 2026 <span className="text-[#475569]">// Built with Next.js</span>
          </div>
        </div>

        {/* Bottom line */}
        <div className="mt-8 pt-8 border-t border-[rgba(255,255,255,0.04)] flex items-center justify-center">
          <div className="font-mono text-[10px] text-[#1e293b] tracking-widest">
            TAPASH.DEV // CLOUD & SECURITY // 2026
          </div>
        </div>
      </div>
    </footer>
  )
}

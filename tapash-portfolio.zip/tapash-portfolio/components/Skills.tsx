'use client'

import { motion, useInView } from 'framer-motion'
import { useRef } from 'react'

const skillCategories = [
  {
    id: 'cloud',
    label: 'Cloud',
    icon: '☁',
    color: '#00a8ff',
    skills: [
      { name: 'Microsoft Azure', level: 85 },
      { name: 'Microsoft 365', level: 90 },
      { name: 'Hybrid Infrastructure', level: 80 },
    ],
  },
  {
    id: 'security',
    label: 'Security',
    icon: '🛡',
    color: '#00ff9d',
    skills: [
      { name: 'Fortinet / FortiGate', level: 88 },
      { name: 'Network Security', level: 82 },
      { name: 'IAM & Zero Trust', level: 78 },
      { name: 'Threat Analysis', level: 75 },
    ],
  },
  {
    id: 'infrastructure',
    label: 'Infrastructure',
    icon: '⚙',
    color: '#0047ff',
    skills: [
      { name: 'Windows Server', level: 92 },
      { name: 'Active Directory', level: 90 },
      { name: 'DFS & NAS', level: 85 },
    ],
  },
  {
    id: 'automation',
    label: 'Automation',
    icon: '⚡',
    color: '#00ff9d',
    skills: [
      { name: 'PowerShell', level: 88 },
      { name: 'Infrastructure Scripting', level: 80 },
    ],
  },
  {
    id: 'devops',
    label: 'DevOps',
    icon: '🔄',
    color: '#00a8ff',
    skills: [
      { name: 'Containers (Docker)', level: 65 },
      { name: 'Kubernetes Basics', level: 55 },
    ],
  },
]

function SkillBar({ name, level, color, delay }: { name: string; level: number; color: string; delay: number }) {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true })

  return (
    <div ref={ref} className="mb-4">
      <div className="flex justify-between items-center mb-1.5">
        <span className="text-[#94a3b8] text-sm">{name}</span>
        <span className="font-mono text-xs text-[#475569]">{level}%</span>
      </div>
      <div className="h-px bg-[rgba(255,255,255,0.05)] relative overflow-hidden">
        <motion.div
          initial={{ width: 0 }}
          animate={isInView ? { width: `${level}%` } : { width: 0 }}
          transition={{ duration: 1.2, delay, ease: [0.4, 0, 0.2, 1] }}
          className="h-full absolute top-0 left-0"
          style={{ background: `linear-gradient(90deg, ${color}, ${color}88)` }}
        >
          {/* Shimmer */}
          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white to-transparent opacity-20"
            style={{ animation: 'shimmer 2s infinite', backgroundSize: '200% 100%' }} />
        </motion.div>
      </div>
    </div>
  )
}

function SkillCard({ category, index }: { category: typeof skillCategories[0]; index: number }) {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: '-50px' })

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 30 }}
      animate={isInView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.6, delay: index * 0.1 }}
      className="cyber-border card-hover bg-[rgba(10,15,30,0.6)] p-6 backdrop-blur-sm"
    >
      {/* Card header */}
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 flex items-center justify-center border"
          style={{ borderColor: `${category.color}33`, background: `${category.color}08` }}>
          <span className="text-lg">{category.icon}</span>
        </div>
        <div>
          <h3 className="font-display font-bold text-[#e2e8f0]">{category.label}</h3>
          <span className="font-mono text-xs text-[#475569]">{category.skills.length} skills</span>
        </div>
        <div className="ml-auto w-2 h-2 rounded-full"
          style={{ background: category.color, boxShadow: `0 0 8px ${category.color}` }} />
      </div>

      {/* Skills */}
      <div>
        {category.skills.map((skill, i) => (
          <SkillBar
            key={skill.name}
            name={skill.name}
            level={skill.level}
            color={category.color}
            delay={index * 0.1 + i * 0.1}
          />
        ))}
      </div>
    </motion.div>
  )
}

export default function Skills() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: '-100px' })

  return (
    <section id="skills" className="relative py-32 px-6">
      {/* Bg accent */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[rgba(0,71,255,0.02)] to-transparent" />

      <div className="max-w-7xl mx-auto" ref={ref}>
        {/* Section label */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={isInView ? { opacity: 1, x: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="flex items-center gap-4 mb-4"
        >
          <span className="section-label">02 // Skills</span>
          <div className="h-px flex-1 max-w-xs bg-gradient-to-r from-[rgba(0,255,157,0.4)] to-transparent" />
        </motion.div>

        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="text-4xl md:text-5xl font-black mb-4"
        >
          Technical <span className="gradient-text-green">Arsenal</span>
        </motion.h2>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.15 }}
          className="text-[#475569] max-w-xl mb-16"
        >
          A curated set of tools and technologies I work with daily in enterprise production environments.
        </motion.p>

        {/* Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
          {skillCategories.map((cat, i) => (
            <SkillCard key={cat.id} category={cat} index={i} />
          ))}
        </div>
      </div>
    </section>
  )
}

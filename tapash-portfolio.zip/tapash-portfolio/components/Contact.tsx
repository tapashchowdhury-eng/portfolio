'use client'

import { motion, useInView } from 'framer-motion'
import { useRef, useState } from 'react'

const socialLinks = [
  {
    name: 'LinkedIn',
    handle: 'tapash-chowdhury75',
    href: 'https://www.linkedin.com/in/tapash-chowdhury75/',
    icon: (
      <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
        <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6zM2 9h4v12H2z"/><circle cx="4" cy="4" r="2"/>
      </svg>
    ),
    color: '#0077b5',
  },
  {
    name: 'GitHub',
    handle: 'tapashchowdhury',
    href: 'https://github.com',
    icon: (
      <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
        <path d="M9 19c-5 1.5-5-2.5-7-3m14 6v-3.87a3.37 3.37 0 0 0-.94-2.61c3.14-.35 6.44-1.54 6.44-7A5.44 5.44 0 0 0 20 4.77 5.07 5.07 0 0 0 19.91 1S18.73.65 16 2.48a13.38 13.38 0 0 0-7 0C6.27.65 5.09 1 5.09 1A5.07 5.07 0 0 0 5 4.77a5.44 5.44 0 0 0-1.5 3.78c0 5.42 3.3 6.61 6.44 7A3.37 3.37 0 0 0 9 18.13V22"/>
      </svg>
    ),
    color: '#e2e8f0',
  },
  {
    name: 'Email',
    handle: 'tapash@example.com',
    href: 'mailto:tapash@example.com',
    icon: (
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/>
      </svg>
    ),
    color: '#00a8ff',
  },
]

export default function Contact() {
  const [formState, setFormState] = useState({ name: '', email: '', subject: '', message: '' })
  const [submitted, setSubmitted] = useState(false)
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: '-100px' })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setSubmitted(true)
  }

  return (
    <section id="contact" className="relative py-32 px-6">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[rgba(0,71,255,0.03)] to-transparent" />

      <div className="max-w-7xl mx-auto relative" ref={ref}>
        {/* Section label */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={isInView ? { opacity: 1, x: 0 } : {}}
          className="flex items-center gap-4 mb-4"
        >
          <span className="section-label">07 // Contact</span>
          <div className="h-px flex-1 max-w-xs bg-gradient-to-r from-[rgba(0,255,157,0.4)] to-transparent" />
        </motion.div>

        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.1 }}
          className="text-4xl md:text-5xl font-black mb-4"
        >
          Get in <span className="gradient-text-blue">Touch</span>
        </motion.h2>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.15 }}
          className="text-[#475569] max-w-xl mb-16"
        >
          Have a project, opportunity, or just want to connect? I&apos;m available for consulting,
          full-time roles, and technical discussions.
        </motion.p>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Contact form */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="lg:col-span-2"
          >
            {submitted ? (
              <div className="cyber-border p-12 text-center">
                <div className="w-16 h-16 border border-[rgba(0,255,157,0.4)] flex items-center justify-center mx-auto mb-6">
                  <span className="text-3xl">✓</span>
                </div>
                <h3 className="text-2xl font-bold text-[#00ff9d] mb-2">Message Sent</h3>
                <p className="text-[#64748b] font-mono text-sm">
                  Thank you. I&apos;ll get back to you shortly.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="font-mono text-xs text-[#475569] tracking-widest uppercase block mb-2">Name</label>
                    <input
                      type="text"
                      required
                      value={formState.name}
                      onChange={(e) => setFormState({ ...formState, name: e.target.value })}
                      className="w-full bg-[rgba(10,15,30,0.8)] border border-[rgba(0,168,255,0.15)] px-4 py-3 font-mono text-sm text-[#e2e8f0] placeholder-[#334155] focus:outline-none focus:border-[rgba(0,168,255,0.5)] transition-colors"
                      placeholder="Your name"
                    />
                  </div>
                  <div>
                    <label className="font-mono text-xs text-[#475569] tracking-widest uppercase block mb-2">Email</label>
                    <input
                      type="email"
                      required
                      value={formState.email}
                      onChange={(e) => setFormState({ ...formState, email: e.target.value })}
                      className="w-full bg-[rgba(10,15,30,0.8)] border border-[rgba(0,168,255,0.15)] px-4 py-3 font-mono text-sm text-[#e2e8f0] placeholder-[#334155] focus:outline-none focus:border-[rgba(0,168,255,0.5)] transition-colors"
                      placeholder="your@email.com"
                    />
                  </div>
                </div>

                <div>
                  <label className="font-mono text-xs text-[#475569] tracking-widest uppercase block mb-2">Subject</label>
                  <input
                    type="text"
                    value={formState.subject}
                    onChange={(e) => setFormState({ ...formState, subject: e.target.value })}
                    className="w-full bg-[rgba(10,15,30,0.8)] border border-[rgba(0,168,255,0.15)] px-4 py-3 font-mono text-sm text-[#e2e8f0] placeholder-[#334155] focus:outline-none focus:border-[rgba(0,168,255,0.5)] transition-colors"
                    placeholder="Project inquiry / Consulting / Other"
                  />
                </div>

                <div>
                  <label className="font-mono text-xs text-[#475569] tracking-widest uppercase block mb-2">Message</label>
                  <textarea
                    required
                    rows={6}
                    value={formState.message}
                    onChange={(e) => setFormState({ ...formState, message: e.target.value })}
                    className="w-full bg-[rgba(10,15,30,0.8)] border border-[rgba(0,168,255,0.15)] px-4 py-3 font-mono text-sm text-[#e2e8f0] placeholder-[#334155] focus:outline-none focus:border-[rgba(0,168,255,0.5)] transition-colors resize-none"
                    placeholder="Tell me about your project or inquiry..."
                  />
                </div>

                <button type="submit" className="btn-primary w-full md:w-auto">
                  <span className="flex items-center justify-center gap-2">
                    Send Message
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/>
                    </svg>
                  </span>
                </button>
              </form>
            )}
          </motion.div>

          {/* Social links */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="space-y-4"
          >
            <h3 className="font-mono text-xs tracking-widest text-[#475569] uppercase mb-6">// Connect</h3>

            {socialLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-4 p-4 cyber-border card-hover group"
              >
                <div className="w-10 h-10 flex items-center justify-center border"
                  style={{ borderColor: `${link.color}33`, color: link.color, background: `${link.color}08` }}>
                  {link.icon}
                </div>
                <div>
                  <div className="text-sm font-bold text-[#e2e8f0] group-hover:text-white transition-colors">{link.name}</div>
                  <div className="font-mono text-xs text-[#475569]">{link.handle}</div>
                </div>
                <svg className="ml-auto text-[#334155] group-hover:text-[#00a8ff] transition-colors" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>
                  <polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/>
                </svg>
              </a>
            ))}

            {/* Location */}
            <div className="p-4 border border-[rgba(255,255,255,0.04)] mt-8">
              <div className="font-mono text-xs text-[#334155] tracking-widest uppercase mb-2">// Status</div>
              <div className="flex items-center gap-2 mb-1">
                <span className="w-2 h-2 rounded-full bg-[#00ff9d] animate-pulse" />
                <span className="text-sm text-[#94a3b8]">Open to opportunities</span>
              </div>
              <div className="font-mono text-xs text-[#334155]">
                Response time: &lt; 24h
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
